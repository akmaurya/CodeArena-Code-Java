package com.mainClass;

public class ThirdClass {

	public void funcThirdFirst() {
		System.out.println("third class func first");
	}
}
