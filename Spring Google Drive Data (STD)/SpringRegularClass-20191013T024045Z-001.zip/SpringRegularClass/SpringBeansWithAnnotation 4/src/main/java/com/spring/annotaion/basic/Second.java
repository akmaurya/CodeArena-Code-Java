package com.spring.annotaion.basic;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class Second {

	
//	public void secFunc() {
//		System.out.println("secondClass");
//	}
	
//	
//	@PostConstruct
//	public void postConstruct() {
//		System.out.println("postConstruct");
//	}
//	
//	@PreDestroy
//	public void preDestroy() {
//		System.out.println("preDestroy");
//	}
	
	
}
