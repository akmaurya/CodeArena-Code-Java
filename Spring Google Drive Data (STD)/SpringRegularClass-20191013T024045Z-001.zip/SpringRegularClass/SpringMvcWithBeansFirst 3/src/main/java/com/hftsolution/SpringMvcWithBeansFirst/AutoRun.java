package com.hftsolution.SpringMvcWithBeansFirst;

public class AutoRun {

	AutoRun(){
		this.alwaysRun();	
	}
	
	public void alwaysRun() {
		System.out.println("am running...");
	}
}
