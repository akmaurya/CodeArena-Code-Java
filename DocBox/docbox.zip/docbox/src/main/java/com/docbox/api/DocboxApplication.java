package com.docbox.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocboxApplication.class, args);
	}

}
