package com.gps.pe.testsuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Test suite to run all the test classes for controller
 * 
 * @author GPS
 *
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({  })
public final class ControllerTestSuite {
}
