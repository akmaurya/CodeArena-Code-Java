package com.gps.pe.dao;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.gps.pe.model.User;
import com.gps.pe.model.UserMapper;
import com.gps.pe.utility.GetSQLQuery;

@Repository
public class UserDaoImpl extends NamedParameterJdbcDaoSupport implements UserDao {

	public User getUserByLoginId(String loginId) {
		String sql = UserQuery.GET_USER_BY_LOGINID.getKeyVal();
		sql = GetSQLQuery.getQuery(sql);
		SqlParameterSource namedParameters = new MapSqlParameterSource("id", loginId);
		return this.getNamedParameterJdbcTemplate().queryForObject(sql, namedParameters, new UserMapper());
	}
	
	/**
	 * Enum to get Query from property file
	 */
	private enum UserQuery {
		GET_USER_BY_LOGINID("pe.user.getUserByLoginId");

		private String key;

		UserQuery(String key) {
			this.key = key;
		}

		String getKeyVal() {
			return key;
		}
	}
}
