package com.gps.pe.service;

public interface UserService {
	public Boolean validateUser(String userName, String Password);
}
