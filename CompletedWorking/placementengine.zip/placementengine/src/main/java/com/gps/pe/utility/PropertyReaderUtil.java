package com.gps.pe.utility;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Utility class to read any property file
 * 
 * @author
 * 
 */
public final class PropertyReaderUtil {

	/**
	 * Method read a property file
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public static Properties readProperties(final String fileRef) throws IOException {
		Properties properties = null;
		properties = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream in = loader.getResourceAsStream(fileRef);
		properties.load(in);
		return properties;
	}

	private PropertyReaderUtil() {
		// Utility class, hide constructor.
	}
}
