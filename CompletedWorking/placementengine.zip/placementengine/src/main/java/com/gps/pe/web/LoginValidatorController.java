package com.gps.pe.web;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.gps.pe.model.User;
import com.gps.pe.service.UserService;

@Controller
public class LoginValidatorController {
	private static final Logger LOGGER = Logger.getLogger(LoginValidatorController.class);
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/JobSeekerloginValidator", method = RequestMethod.POST)
	public ModelAndView jobSeekerValidateLogin(@ModelAttribute("user") User user) {
		LOGGER.debug("Validate Job Seeker Login ...");

		ModelAndView model = null;
		if(userService.validateUser(user.getUserName(), user.getPassword())) {
			model = new ModelAndView("test");
		} else {
			model = new ModelAndView("placementengine");
			model.addObject("centerPageAtrributeHandler", "jobSeekerLogin");
			model.addObject("pageIdentifier", "jobSeekerLogin");
		}
		
		return model;
	}
}
