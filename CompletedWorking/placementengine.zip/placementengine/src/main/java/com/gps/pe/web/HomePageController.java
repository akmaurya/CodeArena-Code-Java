package com.gps.pe.web;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * HomePage controller class to display welcome page, login page & new user
 * registration page
 * 
 * @author GPS
 *
 */
@Controller
public class HomePageController {
	private static final Logger LOGGER = Logger.getLogger(HomePageController.class);

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public final ModelAndView welcomeToPlacementEngine() {
		LOGGER.debug("Home Page Controller called...");
		ModelAndView model = new ModelAndView("placementengine");
		return model;
	}

	@RequestMapping(value = "/jobSeekerLogin", method = RequestMethod.GET)
	public ModelAndView displayLogin() {
		LOGGER.debug("Job Seeker Login Controller called...");

		ModelAndView model = new ModelAndView("placementengine");
		model.addObject("centerPageAtrributeHandler", "jobSeekerLogin");
		model.addObject("pageIdentifier", "jobSeekerLogin");
		return model;
	}

	@RequestMapping(value = "/registerNewJobSeeker", method = RequestMethod.GET)
	public ModelAndView newUserRegistration() {
		LOGGER.debug("New Job Seeker Registration Controller called...");

		ModelAndView model = new ModelAndView("placementengine");
		model.addObject("centerPageAtrributeHandler", "userRegistration");
		model.addObject("pageIdentifier", "userRegistration");
		return model;
	}
}