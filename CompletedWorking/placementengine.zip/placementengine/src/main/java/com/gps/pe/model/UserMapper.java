package com.gps.pe.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		User user = new User();
		user.setUuid(rs.getString("uuid"));
		user.setUserName(rs.getString("login_id"));
		user.setPassword(rs.getString("password"));
		user.setRoleId(rs.getInt("role_roleId"));
		user.setVersion(rs.getInt("version"));
		user.setIsDeleted(rs.getBoolean("isDeleted"));
		return user;
	}
}