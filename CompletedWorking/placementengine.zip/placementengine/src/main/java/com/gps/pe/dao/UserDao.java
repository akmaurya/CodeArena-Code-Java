package com.gps.pe.dao;

import com.gps.pe.model.User;

public interface UserDao {
	public User getUserByLoginId(String loginId);
}
