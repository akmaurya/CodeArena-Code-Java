package com.gps.pe.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gps.pe.dao.UserDao;
import com.gps.pe.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Transactional
	@Override
	public Boolean validateUser(String userName, String Password) {
		boolean validUser = false;
		User user = userDao.getUserByLoginId(userName);
		if (user != null) {
			validUser = (user.getUserName().equals(userName) && user.getPassword().equals(Password) ? true : false);
		}
		return validUser;
	}
}
